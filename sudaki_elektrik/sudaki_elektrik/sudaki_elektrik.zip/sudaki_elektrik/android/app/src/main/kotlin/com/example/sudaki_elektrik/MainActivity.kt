package com.example.sudaki_elektrik

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
