import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';


TextStyle kBaslikStili = TextStyle(
  color: Colors.white,fontSize:27 ,fontWeight:FontWeight.normal
);

TextStyle kMetinStili = TextStyle(
  color: Colors.black54,fontSize: 23,fontWeight: FontWeight.normal
);

